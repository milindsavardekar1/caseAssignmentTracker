import { LightningElement, wire } from 'lwc';
import getCaseAssignmentData from '@salesforce/apex/caseAssignmentTracker.getCaseAssignmentData'; // Update this import statement

export default class CaseAssignmentTracker extends LightningElement {
   caseAssignmentData = [];

   @wire(getCaseAssignmentData)
   wiredCaseAssignmentData({ error, data }) {
       if (data) {
           this.caseAssignmentData = data;
       } else if (error) {
           console.error('Error loading case assignment data', error);
       }
   }
}
